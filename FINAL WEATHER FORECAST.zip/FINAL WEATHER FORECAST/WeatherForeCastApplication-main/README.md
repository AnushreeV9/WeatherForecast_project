# Project - Weather And WeatherForeCast Web-Application🌥🌤🌝🌞

![Design preview for the Weather And WeatherForeCast Web-Application](./fullPage.png)

This is a Weather and Weather forecast web application, which made with HTML, CSS , JavaScript and Weather API .

This Website shows the current weather information and next 6 days weather information of the place you search. 

By default the location set to "Delhi". 

You can search your place by enter the name of your  place in the searach box and than click on the Search button. 

If your place found, it's shows the weather details, but if it not then the previous location weather details will continue to show in the screen.

You always try to  give the correct and valid name of place otherwise it shows an error message.


